package com.ust_global;
import java.util.List;

import javax.ejb.Remote;

@Remote
public interface BooksBeanRemote {
	public void addBook(Books s);
	public List<Books> readAllBook();
	public List<Books> searchByAuthor(String author); 
	public List<Books> searchByBookName(String bookname);
	public List<Books> searchByBookCategory(String category);
    public Books updateBook(String id,String bookname,String author,String publisher,String categoty,int quantity);
    public Books deleteBook(String id);
    public List<Books> SearchBookByID(String Id);
}
