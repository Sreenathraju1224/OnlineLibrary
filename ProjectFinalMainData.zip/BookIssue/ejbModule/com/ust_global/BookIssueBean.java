package com.ust_global;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

@Stateless
public class BookIssueBean implements BookIssueBeanRemote {

	public BookIssueBean()

	{

	}
	
    @PersistenceContext(name = "BookIssueUnit")
	EntityManager entityManager;

	@Override
	public void addData(BookIssue b) {
		entityManager.persist(b);

	}

	@Override
	public List<BookIssue> readAllData() {
		
		
		
		List<BookIssue>readAllData=entityManager.createQuery("FROM Transaction ").getResultList();
		return readAllData;
		
	}

		@Override
	public List<BookIssue> SearchByLoginId(String loginId) {
			System.out.println("1st line");
		List<BookIssue> allBooks=entityManager.createQuery("From Transaction").getResultList();
		for(int i=1;i<allBooks.size();i++)
		{
			System.out.println("this is from book issue" + allBooks.get(i).getLoginId());
		}
		System.out.println("2st line");
		List<BookIssue> searchResult = new ArrayList();
		System.out.println("3st line");
		System.out.println(loginId);
		if(!allBooks.isEmpty())
		{
			System.out.println("helloooo");
		for (BookIssue books:allBooks) 
		{System.out.println("this is from bean "+books.getLoginId());
		System.out.println("this from the method passing login id "+loginId);
				if(books.getLoginId().equalsIgnoreCase(loginId))
				{
					searchResult.add(books);
				}
		}
		}
		else
		{
			System.out.println("Failed");
		}
		return searchResult;
	}

		@Override
		public BookIssue deleteBook(int transactionId) {
			BookIssue delete=entityManager.find(BookIssue.class,transactionId);
			if(delete!=null)
			{
				entityManager.remove(delete);
				System.out.println("Deleting from bean class");
			}
			else
			{
				delete = null;
			}
			return delete;
		}
}
