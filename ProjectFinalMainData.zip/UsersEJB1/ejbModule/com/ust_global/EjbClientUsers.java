package com.ust_global;

import java.util.List;
import java.util.Properties;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

public class EjbClientUsers {

	/**
	 * @param args
	 * @throws NamingException 
	 */
	public static void main(String[] args) throws NamingException {
		Properties p=new Properties();
		p.put(Context.PROVIDER_URL,"localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY,"org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES,"org.jboss.naming:org.jnp.interfaces");
		
		
	
			Context ctx;
			
				ctx = new InitialContext(p);
				UsersBeanRemote user=(UsersBeanRemote) ctx.lookup("UsersBean/remote");
//				Users users= new Users();
//					users.setUserName("Arjun");
//					users.setUserAddress("Alleppy");
//					users.setLoginId("Arjun24");
//					users.setUserPass("Arjun");
//					user.AddUser(users);
//					System.out.println("Added");
//					
					//String username="Arjun";

					
					List<Users> use=user.readAllUsers();
					if(use!=null)
					{
						for (int i = 0; i < use.size(); i++) 
						{
							System.out.println(use.get(i).getUserName()+" "+use.get(i).getUserAddress()+" "+use.get(i).getLoginId());
						}
					}
					else
						System.out.println("result is null");

	}

}
