package com.ust_global;
import java.util.ArrayList;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 * Session Bean implementation class UsersBean
 */
@Stateless
public class UsersBean implements UsersBeanRemote {
    /**
     * Default constructor. 
     */
    public UsersBean() {
        // TODO Auto-generated constructor stub
    }
    @PersistenceContext(name="UsersUnit")
    EntityManager entityManager;
	@Override
	public void AddUser(Users users) {
		entityManager.persist(users);
		
	}
		@Override
	public List<Users> SearchUSerByName(String UserName) {
			List<Users> allusers=entityManager.createQuery("From USERS").getResultList();
			List<Users> searchResult = new ArrayList();
			if(allusers!=null)
			{
			for (Users users:allusers) 
			{
					if(users.getUserName().equalsIgnoreCase(UserName))
					{
						searchResult.add(users);
						
					}
			}
			}
			return searchResult;	
	}
	@Override
	public Users updateusers(int id, String uname, String uaddress,
			String logid, String userpass) {
		Users users =entityManager.find(Users .class, id);
		if(users!=null)
		{
			users.setUserName(uname);
			users.setUserAddress(uaddress);
			users.setLoginId(logid);
			users.setUserPass(userpass);
			
		 entityManager.merge(users);
			}
			else
			{
				users=null;
			}
		 			return users;
	}
	@Override
	public Users DeleteUsers(int id) {
		Users users=	entityManager.find(Users.class, id);
		if(users!=null)
		{
		entityManager.remove(users);
		}
		else
		{
			users=null;
		}
		return users;
	}
	@Override
	public List<Users> readAllUsers() {
		List<Users>allUsers=entityManager.createQuery("FROM USERS").getResultList();
		return allUsers;
	}
	@Override
	public List<Users> SearchUSerByLoginId(String UserLoginID) {
		List<Users> allusers=entityManager.createQuery("From USERS").getResultList();
		List<Users> searchResult = new ArrayList<Users>(); 
		if(allusers!=null)
		{
		for (Users users:allusers) 
		{
				if(users.getLoginId().equalsIgnoreCase(UserLoginID))
				{
					searchResult.add(users);
					
				}
		}
		}
		return searchResult;	
}

	
}
