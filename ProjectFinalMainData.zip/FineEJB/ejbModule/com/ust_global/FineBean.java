package com.ust_global;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 * Session Bean implementation class FineBean
 */
@Stateless
public class FineBean implements FineBeanRemote {
	
	
	  @PersistenceContext(name = "FineCalculationUnit")
		EntityManager entityManager;
    public FineBean() {
        // TODO Auto-generated constructor stub
    }

	@Override
	public void FineDataAdd(Fine fine) {
		entityManager.persist(fine);
		System.out.println("Added to the table successfully");
		
	}

	@Override
	public List<Fine> readAllData() {
		List<Fine>readAllData=entityManager.createQuery("FROM Finecalculation ").getResultList();
		return readAllData;
	}

	@Override
	public List<Fine> SearchByLoginId(String LoginId) {
		System.out.println("1st line");
		List<Fine> fineissue=entityManager.createQuery("From Finecalculation").getResultList();
		for(int i=1;i<fineissue.size();i++)
		{
			System.out.println("this is from fine calculation search method "+fineissue.get(i).loginId);
			
		}
		List<Fine> searchResult = new ArrayList();
		if(!fineissue.isEmpty())
		{
			
		for (Fine fine:fineissue) 
				if(fine.getLoginId().equalsIgnoreCase(LoginId))
				{
					System.out.println("From Search method if " +LoginId);
					searchResult.add(fine);
				}
		}
		
		else
		{
			System.out.println("Failed");
		}
		return searchResult;
	}

}
