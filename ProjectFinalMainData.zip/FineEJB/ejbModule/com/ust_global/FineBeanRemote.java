package com.ust_global;
import java.util.List;

import javax.ejb.Remote;

@Remote
public interface FineBeanRemote {
	public void FineDataAdd(Fine fine);
	 public List<Fine> readAllData();
	 public List<Fine> SearchByLoginId(String LoginId);
}
