import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;


public class datemanipulation {

	/**
	 * @param args
	 * @throws ParseException 
	 */
	public static void main(String[] args) throws ParseException {

		
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		Calendar c = Calendar.getInstance();
		c.setTime(new Date()); // Now use today date.
		String input = sdf.format(c.getTime());
		c.add(Calendar.DATE, 5); // Adding 5 days
		String output = sdf.format(c.getTime());
		System.out.println(input);
		System.out.println(output);
		Date date= new Date();
		java.util.Date date1 = sdf.parse(output);
		java.sql.Date sqlreturnDate = new java.sql.Date(date1.getTime()); 
		java.util.Date date2 = sdf.parse(input);
		java.sql.Date sqlborrowDate = new java.sql.Date(date2.getTime()); 
		System.out.println(sqlborrowDate);
		System.out.println(sqlreturnDate);
		long millisecond1 = sqlborrowDate.getTime();//return date
		long millisecond2 = sqlreturnDate.getTime();//today date
   System.out.println(millisecond1);
    System.out.println(millisecond2);
    if(millisecond1<millisecond2)
    {
    	 long diff = millisecond2 - millisecond1;

      long no=( diff / 1000 / 60 / 60 / 24);
      System.out.println(no);
     long fine=no*5;
     System.out.println(fine);
      
         
    }
	}
	}
