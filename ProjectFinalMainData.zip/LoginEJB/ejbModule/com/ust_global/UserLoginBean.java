package com.ust_global;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.jboss.security.auth.spi.Users;

/**
 * Session Bean implementation class UserLoginBean
 */
@Stateless
public class UserLoginBean implements UserLoginBeanRemote {

    /**
     * Default constructor. 
     */
	@PersistenceContext(name="UserLoginUnit")
	EntityManager entityManager;
    public UserLoginBean() {
        // TODO Auto-generated constructor stub
    }

	@Override
	public boolean validateuser(String Loginid, String Userpass) {
		UserLogin s=null;
		boolean found =false;
		System.out.println("1 "+Loginid+" and  "+Userpass);
		List<UserLogin>  user =entityManager.createQuery("From Users").getResultList();
//		 s =  (UserLogin) entityManager.createQuery("From Users").getSingleResult();//find(UserLogin.class, userid);
		entityManager.flush();
		if (user!=null)
		{
			for (UserLogin users:user) 
			{
				if(users.getLOGINID().equals(Loginid) && users.getUSERPASS().equals(Userpass))
				{
					found = true;
					System.out.println(found);
					break;
					
				}
				
				else
				{
					found=false;
				}
					
			}
		}
		
		else
		{
		s=null;   
		System.out.println("2 going to return "+found);
		found = false;
		}
		
		//System.out.println("3 "+s.getUsername()+"..."+s.getUserPassword());
		return found;
		
	}

	@Override
	public void addUser(UserLogin s) {
		entityManager.persist(s);
		
	}

	@Override
	public UserLogin forgotuser(int id, String name, String address,
			String loginid, String password) {
		 UserLogin updates1 =entityManager.find(UserLogin.class, loginid);
			if(updates1!=null)
			{
				updates1.setUSERID(id);
				updates1.setUSERNAME(name);
				updates1.setUSERADDRESS(address);
				updates1.setLOGINID(loginid);
				updates1.setUSERPASS(password);
				entityManager.merge(updates1);
			}
			else
			{
				updates1=null;
			}
			
			return updates1;
	}

}
