
package com.ust_global;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Properties;

import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.http.HttpSession;

public class UserBean {
	
//	 USERID                                    NOT NULL NUMBER
//	 USERNAME                                           VARCHAR2(30)
//	 USERADDRESS                                        VARCHAR2(100)
//	 LOGINID                                            VARCHAR2(20)
//	 USERPASS                                           VARCHAR2(20)

	int USERID;
	String USERNAME;
	String USERADDRESS;
	String LOGINID;
	String USERPASS;
	String msg;
	String input;
	String option;
	String CONFIRMPASSWORD;

	public int getUSERID() {
		return USERID;
	}
	public String getCONFIRMPASSWORD() {
		return CONFIRMPASSWORD;
	}
	public void setCONFIRMPASSWORD(String cONFIRMPASSWORD) {
		CONFIRMPASSWORD = cONFIRMPASSWORD;
	}
	public void setUSERID(int uSERID) {
		USERID = uSERID;
	}
	public String getUSERNAME() {
		return USERNAME;
	}
	public void setUSERNAME(String uSERNAME) {
		USERNAME = uSERNAME;
	}
	public String getUSERADDRESS() {
		return USERADDRESS;
	}
	public void setUSERADDRESS(String uSERADDRESS) {
		USERADDRESS = uSERADDRESS;
	}
	public String getLOGINID() {
		return LOGINID;
	}
	public void setLOGINID(String lOGINID) {
		LOGINID = lOGINID;
	}
	public String getUSERPASS() {
		return USERPASS;
	}
	public void setUSERPASS(String uSERPASS) {
		USERPASS = uSERPASS;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	public String getInput() {
		return input;
	}
	public void setInput(String input) {
		this.input = input;
	}
	public String getOption() {
		return option;
	}
	public void setOption(String option) {
		this.option = option;
	}
	List<Books> selectedDataList=new ArrayList<Books>();
	List<Users> readUserByLoginID=new ArrayList<Users>();
	List<Users> readUserByUserName=new ArrayList<Users>();
	Users deleteUser1 = new Users();
	Users ForgotPassword1 = new Users();
	
	public Users getForgotPassword1() {
		return ForgotPassword1;
	}
	public void setForgotPassword1(Users forgotPassword1) {
		ForgotPassword1 = forgotPassword1;
	}
	public List<Users> getReadUserByLoginID() {
		return readUserByLoginID;
	}
	public void setReadUserByLoginID(List<Users> readUserByLoginID) {
		this.readUserByLoginID = readUserByLoginID;
	}
	public List<Users> getReadUserByUserName() {
		return readUserByUserName;
	}
	public void setReadUserByUserName(List<Users> readUserByUserName) {
		this.readUserByUserName = readUserByUserName;
	}
	public Users getDeleteUser1() {
		return deleteUser1;
	}
	public void setDeleteUser1(Users deleteUser1) {
		this.deleteUser1 = deleteUser1;
	}
	public String searchUser() throws NamingException
	{
		Properties p=new Properties();
		p.put(Context.PROVIDER_URL,"localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY,"org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES,"org.jboss.naming:org.jnp.interfaces");
		Context ctx=new InitialContext(p);
		UsersBeanRemote userBean =(UsersBeanRemote)ctx.lookup("UsersBean/remote");
		
		FacesContext f = FacesContext.getCurrentInstance();
		ExternalContext ec =f.getExternalContext();
		HttpSession session=(HttpSession)ec.getSession(false);
		String temp=(String) session.getAttribute("LOGINID");
		System.out.println("in bean merhod...."+temp);
		if(option.equalsIgnoreCase("Loginid"))
		{
			readUserByLoginID =   userBean.SearchUSerByLoginId(this.input);
	
			if(!readUserByLoginID.isEmpty())
			{
				msg  = "readUserByLoginID";
			}
			else
			{
				msg = "failed";
			}
		}
		if(option.equalsIgnoreCase("username"))
		{
			readUserByUserName = userBean.SearchUSerByName(this.input);
			if(!readUserByUserName.isEmpty())
			{
				msg = "readUserByUserName";
			}
			else
			{
				msg = "failed";
			}
		}
		return msg;
	}
	public String deleteUsers() throws NamingException
	{
		
		Properties p=new Properties();
		p.put(Context.PROVIDER_URL,"localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY,"org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES,"org.jboss.naming:org.jnp.interfaces");
		Context ctx=new InitialContext(p);
		UsersBeanRemote userBean =(UsersBeanRemote)ctx.lookup("UsersBean/remote");;
		 deleteUser1=userBean.DeleteUsers(this.USERID);	
		if (deleteUser1!=null)
			msg="deleted";
		else
			msg="failed";
		return msg;	
	}
	public String adminLogin() throws NamingException
	{
		
		Properties p=new Properties();
		p.put(Context.PROVIDER_URL, "localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY, "org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES, "org.jboss.naming:org.jnp.interfaces");
		Context ctx= new InitialContext(p);
		UserLoginBeanRemote m =(UserLoginBeanRemote)ctx.lookup("UserLoginBean/remote");
		System.out.println(m);
//		String adminid = "Admin";
//		String adminpass="admin";
//		if(this.LOGINID.equalsIgnoreCase(adminid )&& this.USERPASS.equals(adminpass))
		
		if(m.validateuser(this.LOGINID, this.USERPASS))
		{
			if(this.LOGINID.equalsIgnoreCase("admin" ))
			{
			msg="AdminLogin";
			FacesContext f = FacesContext.getCurrentInstance();
			ExternalContext ec =f.getExternalContext();
			HttpSession session=(HttpSession)ec.getSession(false);
			session.setAttribute("LOGINID",this.LOGINID);
			}
		}
		else
		{
			msg="AdminLoginFailure";
		}
		System.out.println("Returning msg");
		return msg;
	}
	public String userLogin() throws NamingException
	{
		Properties p=new Properties();
		p.put(Context.PROVIDER_URL, "localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY, "org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES, "org.jboss.naming:org.jnp.interfaces");
		Context ctx= new InitialContext(p);
		UserLoginBeanRemote m =(UserLoginBeanRemote)ctx.lookup("UserLoginBean/remote");
		System.out.println("user up"+m);
		System.out.println("user login1"+this.LOGINID);
		System.out.println("user login1"+this.USERPASS);
		if(m.validateuser(this.LOGINID, this.USERPASS))
		{
		System.out.println("user login"+this.LOGINID);
		System.out.println("user login"+this.USERPASS);
			msg="LoginHome";
			FacesContext f = FacesContext.getCurrentInstance();
			ExternalContext ec =f.getExternalContext();
			HttpSession session=(HttpSession)ec.getSession(false);
			session.setAttribute("LOGINID",this.LOGINID);
		}
		else
		{
			msg="LoginFailure";
		}
		System.out.println("Returning msg"+msg);
		return msg;
	}
	public String userLogout()
	{

		System.out.println("reaching logout");
		FacesContext f = FacesContext.getCurrentInstance();
		ExternalContext ec =f.getExternalContext();
		HttpSession session=(HttpSession)ec.getSession(false);
		String msg="";
		if(session!=null)
		{
			System.out.println("session is found");
			String x=(String)session.getAttribute("LOGINID");
			if(x!=null)
			{
				System.out.println("name is found");
				System.out.println("We are sucessfully goint to logout");
				session.removeAttribute("LOGINID");
				session.invalidate();
				msg="AdminLogout1";
			}
		}
		System.out.println("returning "+msg);
		return msg;
	}
	public String userSignin() throws NamingException
	{
		Properties p=new Properties();
		p.put(Context.PROVIDER_URL, "localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY, "org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES, "org.jboss.naming:org.jnp.interfaces");
		Context ctx= new InitialContext(p);
		UserLoginBeanRemote m =(UserLoginBeanRemote)ctx.lookup("UserLoginBean/remote");
		UserLogin ms = new UserLogin();
		ms.setUSERID(USERID);
		ms.setUSERNAME(USERNAME);
		ms.setUSERADDRESS(USERADDRESS);
		ms.setLOGINID(LOGINID);
		ms.setUSERPASS(USERPASS);
		m.addUser(ms);
		
		{
			msg="LoginHomes";
			FacesContext f = FacesContext.getCurrentInstance();
			ExternalContext ec =f.getExternalContext();
			HttpSession session=(HttpSession)ec.getSession(false);
			session.setAttribute("LOGINID",this.LOGINID);
			}
			return msg;
			
		}
	
	public String forgotPassWord() throws NamingException 
	{
		Properties p=new Properties();
		p.put(Context.PROVIDER_URL,"localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY,"org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES,"org.jboss.naming:org.jnp.interfaces");
		Context ctx=new InitialContext(p);
		
		UsersBeanRemote usereRemote=(UsersBeanRemote)ctx.lookup("UsersBean/remote");
		
		List<Users> user=usereRemote.SearchUSerByLoginId(this.LOGINID);
		if(user!=null)
		{
			for (Users u:user) {
				try
				{
					usereRemote.updateusers(u.getUserId(), u.getUserName(), u.getUserAddress(),u.getLoginId() , getUSERPASS());
					if(getUSERPASS().equalsIgnoreCase(this.CONFIRMPASSWORD))
					{
						msg = "passwordreset";
					}
					 
				}
				catch(Exception e)
				{
					msg ="resetFailed";
				}
			}
		}
		//no user
		
		return msg;
		
	}
	
	public int size() {
		return selectedDataList.size();
	}
	public boolean isEmpty() {
		return selectedDataList.isEmpty();
	}
	public boolean contains(Object o) {
		return selectedDataList.contains(o);
	}
	public Iterator<Books> iterator() {
		return selectedDataList.iterator();
	}
	public Object[] toArray() {
		return selectedDataList.toArray();
	}
	public <T> T[] toArray(T[] a) {
		return selectedDataList.toArray(a);
	}
	public boolean add(Books e) {
		return selectedDataList.add(e);
	}
	public boolean remove(Object o) {
		return selectedDataList.remove(o);
	}
	public boolean containsAll(Collection<?> c) {
		return selectedDataList.containsAll(c);
	}
	public boolean addAll(Collection<? extends Books> c) {
		return selectedDataList.addAll(c);
	}
	public boolean addAll(int index, Collection<? extends Books> c) {
		return selectedDataList.addAll(index, c);
	}
	public boolean removeAll(Collection<?> c) {
		return selectedDataList.removeAll(c);
	}
	public boolean retainAll(Collection<?> c) {
		return selectedDataList.retainAll(c);
	}
	public void clear() {
		selectedDataList.clear();
	}
	public boolean equals(Object o) {
		return selectedDataList.equals(o);
	}
	public int hashCode() {
		return selectedDataList.hashCode();
	}
	public Books get(int index) {
		return selectedDataList.get(index);
	}
	public Books set(int index, Books element) {
		return selectedDataList.set(index, element);
	}
	public List<Books> getSelectedDataList() {
		return selectedDataList;
	}
	public void setSelectedDataList(List<Books> selectedDataList) {
		this.selectedDataList = selectedDataList;
	}
	public void add(int index, Books element) {
		selectedDataList.add(index, element);
	}
	public Books remove(int index) {
		return selectedDataList.remove(index);
	}

	
	}
	
		

