package com.ust_global;
import java.nio.channels.SeekableByteChannel;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.Random;

import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.jms.Session;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.http.HttpSession;

import org.apache.bsf.util.Bean;
public class test {
	String 	BOOKID;
	String 	BOOKNAME;
	String 	BOOKAUTHOR;
	String 	BOOKPUBLISHER;
	String 	BOOKCATEGORY;
	int  	BOOKQUANTITY;
	String 	msg;
	String 	option;
	String 	input;
	String checkbox[]=new String[5];
	private List<Books> items;



	public String[] getCheckbox() {
		return checkbox;
	}
	public void setCheckbox(String[] checkbox) {
		this.checkbox = checkbox;
	}
	public String getBOOKID() {
		return BOOKID;
	}
	public void setBOOKID(String bOOKID) {
		BOOKID = bOOKID;
	}
	public String getBOOKNAME() {
		return BOOKNAME;
	}
	public void setBOOKNAME(String bOOKNAME) {
		BOOKNAME = bOOKNAME;
	}
	public String getBOOKAUTHOR() {
		return BOOKAUTHOR;
	}
	public void setBOOKAUTHOR(String bOOKAUTHOR) {
		BOOKAUTHOR = bOOKAUTHOR;
	}
	public String getBOOKPUBLISHER() {
		return BOOKPUBLISHER;
	}
	public void setBOOKPUBLISHER(String bOOKPUBLISHER) {
		BOOKPUBLISHER = bOOKPUBLISHER;
	}
	public String getBOOKCATEGORY() {
		return BOOKCATEGORY;
	}
	public void setBOOKCATEGORY(String bOOKCATEGORY) {
		BOOKCATEGORY = bOOKCATEGORY;
	}
	public int getBOOKQUANTITY() {
		return BOOKQUANTITY;
	}
	public void setBOOKQUANTITY(int bOOKQUANTITY) {
		BOOKQUANTITY = bOOKQUANTITY;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	public String getOption() {
		return option;
	}
	public void setOption(String option) {
		this.option = option;
	}
	public String getInput() {
		return input;
	}
	public void setInput(String input) {
		this.input = input;
	}
	public test() {
		super();
	}
	
	public List<Books> getSearchBooksByAuthor() {
		return searchBooksByAuthor;
	}
	public void setSearchBooksByAuthor(List<Books> searchBooksByAuthor) {
		this.searchBooksByAuthor = searchBooksByAuthor;
	}
	public List<Books> getSearchBooksByBookName() {
		return searchBooksByBookName;
	}
	public void setSearchBooksByBookName(List<Books> searchBooksByBookName) {
		this.searchBooksByBookName = searchBooksByBookName;
	}
	public List<Books> getReadAllBooks() {
		return readAllBooks;
	}
	public void setReadAllBooks(List<Books> readAllBooks) {
		this.readAllBooks = readAllBooks;
	}
	public Books getUpdateBook1() {
		return updateBook1;
	}
	public void setUpdateBook1(Books updateBook1) {
		this.updateBook1 = updateBook1;
	}
	public Books getDeleteBook1() {
		return deleteBook1;
	}
	public void setDeleteBook1(Books deleteBook1) {
		this.deleteBook1 = deleteBook1;
	}
	public List<Books> getSearchByBookCategory() {
		return searchByBookCategory;
	}
	public void setSearchByBookCategory(List<Books> searchByBookCategory) {
		this.searchByBookCategory = searchByBookCategory;
	}
	List<Books> searchBooksByAuthor=new ArrayList<Books>();
	List<Books> searchBooksByBookName=new ArrayList<Books>();
	List<Books> searchByBookCategory = new ArrayList<Books>();
	List<Books> searchById = new ArrayList<Books>();
	List<Books> readAllBooks=new ArrayList<Books>();
	List<BookIssue> searchbyLoginId = new ArrayList();
	List<Fine> searchbyLoginIdFine = new ArrayList();
	public List<Fine> getSearchbyLoginIdFine() {
		return searchbyLoginIdFine;
	}
	public void setSearchbyLoginIdFine(List<Fine> searchbyLoginIdFine) {
		this.searchbyLoginIdFine = searchbyLoginIdFine;
	}
	public List<BookIssue> getSearchbyLoginId() {
		return searchbyLoginId;
	}
	public void setSearchbyLoginId(List<BookIssue> searchbyLoginId) {
		this.searchbyLoginId = searchbyLoginId;
	}
	Books updateBook1=new Books();
	public List<Books> getSearchById() {
		return searchById;
	}
	public void setSearchById(List<Books> searchById) {
		this.searchById = searchById;
	}
	Books deleteBook1 = new Books();
	public String addBook() throws NamingException
	{
		

		Properties p=new Properties();
		p.put(Context.PROVIDER_URL,"localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY,"org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES,"org.jboss.naming:org.jnp.interfaces");
		Context ctx=new InitialContext(p);
		BooksBeanRemote bookBean =(BooksBeanRemote)ctx.lookup("BooksBean/remote");
		List<Books> readAllBooks =  bookBean.readAllBook();
		Books b=new Books();
		
		System.out.println(readAllBooks);

		try
		{
			if(bookBean!=null)
			{ 
		for(int i =0;i<readAllBooks.size();i++)
		{
			Books b1=(Books)readAllBooks.get(i);
		if(BOOKQUANTITY <=0 )
		{	
			msg = "The Book quantity should be greater than zero";
			return "added";
		}

		else if(b1.getBOOKID().equalsIgnoreCase(BOOKID))
		{
			msg = "The BooKID is already existed";
			
			System.exit(0);
			break;
			
		}
		
		else
		{
		b.setBOOKID(BOOKID);
		b.setBOOKNAME(BOOKNAME);
		b.setBOOKAUTHOR(BOOKAUTHOR);
		b.setBOOKPUBLISHER(BOOKAUTHOR);
		b.setBOOKPUBLISHER(BOOKPUBLISHER);
		b.setBOOKCATEGORY(BOOKCATEGORY);
		b.setBOOKQUANTITY(BOOKQUANTITY);
			bookBean.addBook(b);
			msg = "The Book is Successfulyy added";
			return "added";
		}
			
	}
		}
		}
		catch (Exception e) {
			msg = "The request is Failed .Check the BookId is existing or not";
			
		}
		
		
		return msg;
	}
	
	
	
	public String updateBook() throws NamingException
	{
		
		Properties p=new Properties();
		p.put(Context.PROVIDER_URL,"localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY,"org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES,"org.jboss.naming:org.jnp.interfaces");
		Context ctx=new InitialContext(p);
		BooksBeanRemote bookBean =(BooksBeanRemote)ctx.lookup("BooksBean/remote");
		updateBook1.setBOOKID(this.BOOKID);
		updateBook1.setBOOKNAME(this.BOOKNAME);
		updateBook1.setBOOKAUTHOR(this.BOOKAUTHOR);
		updateBook1.setBOOKPUBLISHER(this.BOOKPUBLISHER);
		updateBook1.setBOOKCATEGORY(this.BOOKCATEGORY);
		updateBook1.setBOOKQUANTITY(this.BOOKQUANTITY);
		try{
			 bookBean.updateBook(BOOKID, BOOKNAME, BOOKAUTHOR, BOOKPUBLISHER, BOOKCATEGORY, BOOKQUANTITY);
			 msg = "updated";
		}
		catch(Exception e)
		{
			msg ="failed";
		}
		return msg;
		
	}
	public String deleteBook() throws NamingException
	{
		Properties p=new Properties();
		p.put(Context.PROVIDER_URL,"localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY,"org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES,"org.jboss.naming:org.jnp.interfaces");
		Context ctx=new InitialContext(p);
		BooksBeanRemote bookBean =(BooksBeanRemote)ctx.lookup("BooksBean/remote");
		deleteBook1=bookBean.deleteBook(BOOKID);
		if (deleteBook1!=null)
			msg="deleted";
		else
			msg="failed";
		
		System.out.println("deleteBook returning "+msg);
		return msg;
		
	}
	public String searchBooks() throws NamingException
	{
		Properties p=new Properties();
		p.put(Context.PROVIDER_URL,"localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY,"org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES,"org.jboss.naming:org.jnp.interfaces");
		Context ctx=new InitialContext(p);
		BooksBeanRemote bookBean =(BooksBeanRemote)ctx.lookup("BooksBean/remote");
		if(option.equalsIgnoreCase("bookName"))
		{
			searchBooksByBookName = bookBean.searchByBookName(this.input);
			if(!searchBooksByBookName.isEmpty())
			{
				msg  = "SearchbyBookName";
			}
			else
			{
				msg = "failed";
			}
		}
		if(option.equalsIgnoreCase("bookAuthor"))
		{
			searchBooksByAuthor = bookBean.searchByAuthor(this.input);
			if(!searchBooksByAuthor.isEmpty())
			{
				msg  = "SearchBooksByAuthor";
			}
			else
			{
				msg = "failed";
			}
		}
		if(option.equalsIgnoreCase("bookCategory"))
		{
			searchByBookCategory = bookBean.searchByBookCategory(this.input);
			if(!searchByBookCategory.isEmpty())
			{
				msg  = "SearchByBookCategory";
			}
			else
			{
				msg = "failed";
			}
		}
		return msg;
	}
	
	public String Lending() throws NamingException, ParseException
	{
		
		Properties p=new Properties();
		p.put(Context.PROVIDER_URL,"localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY,"org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES,"org.jboss.naming:org.jnp.interfaces");
		FacesContext f = FacesContext.getCurrentInstance();
		ExternalContext ec =f.getExternalContext();
		HttpSession session=(HttpSession)ec.getSession(false);
		Context ctx=new InitialContext(p);
		BooksBeanRemote bookBean =(BooksBeanRemote)ctx.lookup("BooksBean/remote");
		BookIssueBeanRemote bookissue=(BookIssueBeanRemote) ctx.lookup("BookIssueBean/remote");
		System.out.println(checkbox+"test");
		System.out.println(checkbox.length);
	//	System.out.println(session.getAttribute("LOGINID"));
		String loginid=(String) session.getAttribute("LOGINID");
		System.out.println(loginid);
		for (int i = 0; i < checkbox.length; i++) 
		{
			System.out.println(checkbox[i]);
			searchById=bookBean.SearchBookByID(checkbox[i]);
			for(Books b:searchById)
			{
			if(b.BOOKQUANTITY>0)
			{
					int counter=0;
					counter=b.BOOKQUANTITY-1;
					bookBean.updateBook(b.BOOKID, b.BOOKNAME, b.BOOKAUTHOR, b.BOOKPUBLISHER,b.BOOKCATEGORY, counter);
			BookIssue bki=new BookIssue();
			Random r=new Random();
			int rand=r.nextInt((5000-11)+1)+11;
			
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
			Calendar c = Calendar.getInstance();
			c.setTime(new Date()); // Now use today date.
			String input = sdf.format(c.getTime());
			c.add(Calendar.DATE, 5); // Adding 5 days
			String output = sdf.format(c.getTime());
			System.out.println(input);
			System.out.println(output);
			java.util.Date date1 = sdf.parse(output);
			java.sql.Date sqlreturnDate = new java.sql.Date(date1.getTime()); 
			java.util.Date date2 = sdf.parse(input);
			java.sql.Date sqlborrowDate = new java.sql.Date(date2.getTime()); 
			        bki.bookId=b.BOOKID;
					bki.bookName=b.BOOKNAME;
					bki.bookAuthor=b.BOOKAUTHOR;
					bki.transactionId=rand;
					bki.loginId=loginid;
					bki.bookCategory=b.BOOKCATEGORY;
					bki.issueDate=sqlborrowDate;
					bki.returnDate=sqlreturnDate;
					bookissue.addData(bki);
					
		}
				
			}
			if(!searchById.isEmpty())
			{
				msg  = "SearchbyID";
			}
			else
			{
				msg = "failed";
			}
			
		}
			     return msg;
	}
	public String Return() throws NamingException, ParseException
	{
		Properties p=new Properties();
		p.put(Context.PROVIDER_URL,"localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY,"org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES,"org.jboss.naming:org.jnp.interfaces");
		Context ctx=new InitialContext(p);
		FacesContext f = FacesContext.getCurrentInstance();
		ExternalContext ec =f.getExternalContext();
		HttpSession session=(HttpSession)ec.getSession(false);
		BooksBeanRemote bookBean =(BooksBeanRemote)ctx.lookup("BooksBean/remote");
		BookIssueBeanRemote bookissue=(BookIssueBeanRemote) ctx.lookup("BookIssueBean/remote");
		FineBeanRemote fine=(FineBeanRemote) ctx.lookup("FineBean/remote");
		String loginid=(String) session.getAttribute("LOGINID");
		System.out.println("this is from retuen methord " +loginid);
		searchbyLoginId=bookissue.SearchByLoginId(loginid);
		System.out.println(checkbox+"test");
		System.out.println(checkbox.length);
		for (int i = 0; i < checkbox.length; i++) 
		{
			System.out.println(checkbox[i]);
			searchById=bookBean.SearchBookByID(checkbox[i]);
			for(Books b:searchById)
			{
			int counter=0;
					counter=b.BOOKQUANTITY+1;
					
					bookBean.updateBook(b.BOOKID, b.BOOKNAME, b.BOOKAUTHOR, b.BOOKPUBLISHER,b.BOOKCATEGORY, counter);

					Fine fn=new Fine();
					Random r=new Random();
					int rand=r.nextInt((5000-11)+1)+11;
					
					java.sql.Date output =searchbyLoginId.get(i).returnDate;
								
					SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
					Calendar c = Calendar.getInstance();
					c.setTime(new Date()); // Now use today date.
					String input = sdf.format(c.getTime());
					System.out.println(input);
					System.out.println(output);
					//java.util.Date date1 = sdf.parse(output);
					java.sql.Date sqlreturnDate = new java.sql.Date(output.getTime()); 
					java.util.Date date2 = sdf.parse(input);
					java.sql.Date sqltodayDate = new java.sql.Date(date2.getTime());
					long millisecond1 = sqlreturnDate.getTime();//return date
					long millisecond2 = sqltodayDate.getTime();//today date
					System.out.println(millisecond1);
					System.out.println(millisecond2);
					long fine1=0;
					if(millisecond1<millisecond2)
					{
			    	 long diff = millisecond2 - millisecond1;

			    	 long no=( diff / 1000 / 60 / 60 / 24);
			    	 System.out.println(no);
			    	  fine1=no*5;
			    	 System.out.println(fine1);
					}
					fn.setTransId(rand);
					fn.setBookId(b.BOOKID);
					fn.setBookName(b.BOOKNAME);
					fn.setIssueDate(searchbyLoginId.get(i).getIssueDate());
					fn.setReturnDate(searchbyLoginId.get(i).getReturnDate());
					fn.setCurrentDate(date2);
					fn.setLoginId(loginid);
					fn.setFine(fine1);
					fine.FineDataAdd(fn);
					
					if((searchbyLoginId.get(i).transactionId)!=0)
					{
			bookissue.deleteBook(searchbyLoginId.get(i).transactionId) ;
			System.out.println(searchbyLoginId.get(i).transactionId);
					}
					
					else 
					{
						msg = "failed1";
					}
			if(!searchById.isEmpty())
			{
				msg  = "Returned";
			}
			else
			{
				msg = "failed";
			}
		}	    
	}
	
		System.out.println(msg);
		 return msg;
	}
	public String ShowBooks() throws NamingException
	{
		Properties p=new Properties();
		p.put(Context.PROVIDER_URL,"localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY,"org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES,"org.jboss.naming:org.jnp.interfaces");
		FacesContext f = FacesContext.getCurrentInstance();
		ExternalContext ec =f.getExternalContext();
		HttpSession session=(HttpSession)ec.getSession(false);
		Context ctx=new InitialContext(p);
		BookIssueBeanRemote bookissue=(BookIssueBeanRemote) ctx.lookup("BookIssueBean/remote");	
		String loginid=(String) session.getAttribute("LOGINID");
		searchbyLoginId=bookissue.SearchByLoginId(loginid);
		System.out.println("this is from show books"+ loginid);
		if(searchbyLoginId.isEmpty())
		{
			msg="failed";
		}
			
		else
		{
			
			msg="SearchbyLoginId";
		}
				
		return msg;
	}
	public String FineCalculation() throws NamingException
	{
		Properties p=new Properties();
		p.put(Context.PROVIDER_URL,"localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY,"org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES,"org.jboss.naming:org.jnp.interfaces");
		FacesContext f = FacesContext.getCurrentInstance();
		ExternalContext ec =f.getExternalContext();
		HttpSession session=(HttpSession)ec.getSession(false);
		Context ctx=new InitialContext(p);
		FineBeanRemote finemethod=(FineBeanRemote)ctx.lookup("FineBean/remote");	
		String loginid=(String) session.getAttribute("LOGINID");
		System.out.println("this is from fine calculation"+loginid);
		searchbyLoginIdFine=finemethod.SearchByLoginId(loginid);
		if(searchbyLoginIdFine.isEmpty())
		{
			msg="failed";
		}
			
		else
		{
			
			msg="Fines";
		}
				
		return msg;
	}
	
}
