package com.ust_global;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
public class BookBean {
	String BOOKID;
	String BOOKNAME;
	String BOOKAUTHOR;
	String BOOKPUBLISHER;
	String BOOKCATEGORY;
	int  BOOKQUANTITY;
	String msg;
	String option;
	String input;
	public String getBOOKID() {
		return BOOKID;
	}
	public void setBOOKID(String bOOKID) {
		BOOKID = bOOKID;
	}
	public String getBOOKNAME() {
		return BOOKNAME;
	}
	public void setBOOKNAME(String bOOKNAME) {
		BOOKNAME = bOOKNAME;
	}
	public String getBOOKAUTHOR() {
		return BOOKAUTHOR;
	}
	public void setBOOKAUTHOR(String bOOKAUTHOR) {
		BOOKAUTHOR = bOOKAUTHOR;
	}
	public String getBOOKPUBLISHER() {
		return BOOKPUBLISHER;
	}
	public void setBOOKPUBLISHER(String bOOKPUBLISHER) {
		BOOKPUBLISHER = bOOKPUBLISHER;
	}
	public String getBOOKCATEGORY() {
		return BOOKCATEGORY;
	}
	public void setBOOKCATEGORY(String bOOKCATEGORY) {
		BOOKCATEGORY = bOOKCATEGORY;
	}
	public int getBOOKQUANTITY() {
		return BOOKQUANTITY;
	}
	public void setBOOKQUANTITY(int bOOKQUANTITY) {
		BOOKQUANTITY = bOOKQUANTITY;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	public String getOption() {
		return option;
	}
	public void setOption(String option) {
		this.option = option;
	}
	public String getInput() {
		return input;
	}
	public void setInput(String input) {
		this.input = input;
	}
	public BookBean() {
		super();
	}
	
	public List<Books> getSearchBooksByAuthor() {
		return searchBooksByAuthor;
	}
	public void setSearchBooksByAuthor(List<Books> searchBooksByAuthor) {
		this.searchBooksByAuthor = searchBooksByAuthor;
	}
	public List<Books> getSearchBooksByBookName() {
		return searchBooksByBookName;
	}
	public void setSearchBooksByBookName(List<Books> searchBooksByBookName) {
		this.searchBooksByBookName = searchBooksByBookName;
	}
	public List<Books> getReadAllBooks() {
		return readAllBooks;
	}
	public void setReadAllBooks(List<Books> readAllBooks) {
		this.readAllBooks = readAllBooks;
	}
	public Books getUpdateBook1() {
		return updateBook1;
	}
	public void setUpdateBook1(Books updateBook1) {
		this.updateBook1 = updateBook1;
	}
	public Books getDeleteBook1() {
		return deleteBook1;
	}
	public void setDeleteBook1(Books deleteBook1) {
		this.deleteBook1 = deleteBook1;
	}
	public List<Books> getSearchByBookCategory() {
		return searchByBookCategory;
	}
	public void setSearchByBookCategory(List<Books> searchByBookCategory) {
		this.searchByBookCategory = searchByBookCategory;
	}
	List<Books> searchBooksByAuthor=new ArrayList<Books>();
	List<Books> searchBooksByBookName=new ArrayList<Books>();
	List<Books> searchByBookCategory = new ArrayList<Books>();
	List<Books> readAllBooks=new ArrayList<Books>();
	Books updateBook1=new Books();
	Books deleteBook1 = new Books();
	public String addBook() throws NamingException
	{
		Books b=new Books();
		b.setBOOKID(BOOKID);
		b.setBOOKNAME(BOOKNAME);
		b.setBOOKAUTHOR(BOOKAUTHOR);
		b.setBOOKPUBLISHER(BOOKAUTHOR);
		b.setBOOKPUBLISHER(BOOKPUBLISHER);
		b.setBOOKCATEGORY(BOOKCATEGORY);
		b.setBOOKQUANTITY(BOOKQUANTITY);
		Properties p=new Properties();
		p.put(Context.PROVIDER_URL,"localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY,"org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES,"org.jboss.naming:org.jnp.interfaces");
		Context ctx=new InitialContext(p);
		BooksBeanRemote bookBean =(BooksBeanRemote)ctx.lookup("BooksBean/remote");
		if(bookBean!=null)
		{
			bookBean.addBook(b);
			msg="added";
		}
		else
			msg="failed";
		
		return msg;
	}
	public String updateBook() throws NamingException
	{
		
		Properties p=new Properties();
		p.put(Context.PROVIDER_URL,"localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY,"org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES,"org.jboss.naming:org.jnp.interfaces");
		Context ctx=new InitialContext(p);
		BooksBeanRemote bookBean =(BooksBeanRemote)ctx.lookup("BooksBean/remote");
		updateBook1.setBOOKID(this.BOOKID);
		updateBook1.setBOOKNAME(this.BOOKNAME);
		updateBook1.setBOOKAUTHOR(this.BOOKAUTHOR);
		updateBook1.setBOOKPUBLISHER(this.BOOKPUBLISHER);
		updateBook1.setBOOKCATEGORY(this.BOOKCATEGORY);
		updateBook1.setBOOKQUANTITY(this.BOOKQUANTITY);
		try{
			 bookBean.updateBook(BOOKID, BOOKNAME, BOOKAUTHOR, BOOKPUBLISHER, BOOKCATEGORY, BOOKQUANTITY);
			 msg = "updated";
		}
		catch(Exception e)
		{
			msg ="failed";
		}
		return msg;
		
	}
	public String deleteBook() throws NamingException
	{
		Properties p=new Properties();
		p.put(Context.PROVIDER_URL,"localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY,"org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES,"org.jboss.naming:org.jnp.interfaces");
		Context ctx=new InitialContext(p);
		BooksBeanRemote bookBean =(BooksBeanRemote)ctx.lookup("BooksBean/remote");
		if(bookBean!=null)
		{
		
			bookBean.deleteBook(this.BOOKID);
			msg="deleted";
		}
		else
			msg="failed";
		return msg;
		
	}
	public String searchBooks() throws NamingException
	{
		Properties p=new Properties();
		p.put(Context.PROVIDER_URL,"localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY,"org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES,"org.jboss.naming:org.jnp.interfaces");
		Context ctx=new InitialContext(p);
		BooksBeanRemote bookBean =(BooksBeanRemote)ctx.lookup("BooksBean/remote");
		if(option.equalsIgnoreCase("bookName"))
		{
			searchBooksByBookName = bookBean.searchByBookName(this.input);
			if(!searchBooksByBookName.isEmpty())
			{
				msg  = "SearchbyBookName";
			}
			else
			{
				msg = "failed";
			}
		}
		if(option.equalsIgnoreCase("bookAuthor"))
		{
			searchBooksByAuthor = bookBean.searchByAuthor(this.input);
			if(!searchBooksByAuthor.isEmpty())
			{
				msg  = "SearchBooksByAuthor";
			}
			else
			{
				msg = "failed";
			}
		}
		if(option.equalsIgnoreCase("bookCategory"))
		{
			searchByBookCategory = bookBean.searchByBookCategory(this.input);
			if(!searchByBookCategory.isEmpty())
			{
				msg  = "SearchByBookCategory";
			}
			else
			{
				msg = "failed";
			}
		}
		return msg;
	}
}
