package com.ust_global;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

public class UsersBean {

	
	int userId;
	String userName;
	String userAddress;
	String loginId;
	String userPass;
	
	String msg;
	
	
	
	
    public UsersBean() {
		super();
	}
	
    List<Users>SearchUSerByName=new ArrayList<Users>();
    List<Users>readAllUsers=new ArrayList<Users>();
	Users updateusers=new Users();
    Users DeleteUsers=new Users();
    
    public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserAddress() {
		return userAddress;
	}
	public void setUserAddress(String userAddress) {
		this.userAddress = userAddress;
	}
	public String getLoginId() {
		return loginId;
	}
	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}
	public String getUserPass() {
		return userPass;
	}
	public void setUserPass(String userPass) {
		this.userPass = userPass;
	}
	public List<Users> getSearchUSerByName() {
		return SearchUSerByName;
	}
	public void setSearchUSerByName(List<Users> searchUSerByName) {
		SearchUSerByName = searchUSerByName;
	}
	public List<Users> getReadAllUsers() {
		return readAllUsers;
	}
	public void setReadAllUsers(List<Users> readAllUsers) {
		this.readAllUsers = readAllUsers;
	}
	public Users getUpdateusers() {
		return updateusers;
	}
	public void setUpdateusers(Users updateusers) {
		this.updateusers = updateusers;
	}
	public Users getDeleteUsers() {
		return DeleteUsers;
	}
	public void setDeleteUsers(Users deleteUsers) {
		DeleteUsers = deleteUsers;
	}
	
	
	public String AddUser() throws NamingException
	{
		
		
		Users u=new Users();
		u.setUserId(userId);
		u.setUserName(userName);
		u.setUserAddress(userAddress);
		u.setLoginId(loginId);
		u.setUserPass(userPass);
		
		
		
		Properties p=new Properties();
		p.put(Context.PROVIDER_URL,"localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY,"org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES,"org.jboss.naming:org.jnp.interfaces");
		Context ctx=new InitialContext(p);
		
		UsersBeanRemote usersremote=(UsersBeanRemote) ctx.lookup("UsersBean/remote");
		
		if(usersremote!=null)
		{
			usersremote.AddUser(u);
			msg="dataAdded";
		}
		else
			msg="failed";

		
		return msg;
	}
	
}


//public String DeleteUsers(String id)throws NamingException 
//{
//
//	Properties p=new Properties();
//	p.put(Context.PROVIDER_URL,"localhost:1099");
//	p.put(Context.INITIAL_CONTEXT_FACTORY,"org.jnp.interfaces.NamingContextFactory");
//	p.put(Context.URL_PKG_PREFIXES,"org.jboss.naming:org.jnp.interfaces");
//	Context ctx=new InitialContext(p);
//	
//	
//	UsersBeanRemote usersremote=(UsersBeanRemote) ctx.lookup("UsersBean/remote");
//	
//	if(usersremote!=null)
//	{
//		
//		usersremote.DeleteUsers(id);
//		msg="deletedData";
//	}
//		
//	
//	else
//	{
//		msg="failed";
//}
//	return msg;
//}
//}







		
		
		
		

		
	
	
	
	
	
	
	
	
	


 

