package com.ust_global;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

public class BookIssueBean {

	
	int transId;
	String userName;
	String bookId;
	String bookName;
	Date dateOfIssue;
	Date dateOfReturn;
	int fine;
	String msg;
	
	
	public BookIssueBean() {
		super();
	}
	    List<BookIssue>readAllData1=new ArrayList<BookIssue>();

		
		
	
	public List<BookIssue> getReadAllData1() {
			return readAllData1;
		}
		public void setReadAllData1(List<BookIssue> readAllData1) {
			this.readAllData1 = readAllData1;
		}
	public int getTransId() {
		return transId;
	}
	public void setTransId(int transId) {
		this.transId = transId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getBookId() {
		return bookId;
	}
	public void setBookId(String bookId) {
		this.bookId = bookId;
	}
	public String getBookName() {
		return bookName;
	}
	public void setBookName(String bookName) {
		this.bookName = bookName;
	}
	public Date getDateOfIssue() {
		return dateOfIssue;
	}
	public void setDateOfIssue(Date dateOfIssue) {
		this.dateOfIssue = dateOfIssue;
	}
	public Date getDateOfReturn() {
		return dateOfReturn;
	}
	public void setDateOfReturn(Date dateOfReturn) {
		this.dateOfReturn = dateOfReturn;
	}
	public int getFine() {
		return fine;
	}
	public void setFine(int fine) {
		this.fine = fine;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	
	
	
	public String  addData() throws NamingException
	{
		
		BookIssue bi=new BookIssue();
		
		
		bi.setTransId(transId);
		bi.setUserName(userName);
		bi.setBookId(bookId);
		bi.setBookName(bookName);
        bi.setFine(fine);
        
        
		java.util.Date utilDate=new java.util.Date(2016,8,21);
		long ms=utilDate.getTime();
		java.sql.Date sqlDate=new Date(ms);
		
		java.util.Date utilDate1=new java.util.Date(2016,8,30);
		long ms2=utilDate1.getTime();
		java.sql.Date sqlDate1=new Date(ms2);
		
		
		bi.setDateOfIssue(sqlDate);
		bi.setDateOfReturn(sqlDate1);
		
		
		
		
		
		
		Properties p=new Properties();
		p.put(Context.PROVIDER_URL,"localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY,"org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES,"org.jboss.naming:org.jnp.interfaces");
		Context ctx=new InitialContext(p);
	    BookIssueBeanRemote bookremote=(BookIssueBeanRemote) ctx.lookup("BookIssueBean/remote");
		
		if(bookremote!=null)
		{
			bookremote.addData(bi);
			
			msg="dataAdded";
		}
		else
			msg="failed";

	    return msg;
	    
	}
	
	
	public String readAllData() throws NamingException
	{
		Properties p=new Properties();
		p.put(Context.PROVIDER_URL,"localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY,"org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES,"org.jboss.naming:org.jnp.interfaces");
		Context ctx=new InitialContext(p);
	    BookIssueBeanRemote bookremote=(BookIssueBeanRemote) ctx.lookup("BookIssueBean/remote");

		
		readAllData1=bookremote.readAllData(); 
		if(readAllData1!=null)
			msg="readAllData";
		else
			msg="failed";
		return msg;
	}
	
}
	
	
	
	
	
	
	
	
	
	

	

		

		


	
	
	
	
	

