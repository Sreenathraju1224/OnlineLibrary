package com.ust_global;
import java.util.ArrayList;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 * Session Bean implementation class BooksBean
 */
@Stateless
public class BooksBean implements BooksBeanRemote {

    /**
     * Default constructor. 
     */
	@PersistenceContext(name="BooksUnit")
	EntityManager entityManager;
    public BooksBean() {
        // TODO Auto-generated constructor stub
    }
	@Override
	public void addBook(Books s) {
		entityManager.persist(s);
	}
	@Override
	public List<Books> readAllBook() {
		List<Books> allbooks=entityManager.createQuery("FROM Books").getResultList();
		return allbooks;	
	}
	@Override
	public List<Books> searchByAuthor(String author) {
		List<Books> allBooks=entityManager.createQuery("From Books").getResultList();
		List<Books> searchResult = new ArrayList();
		if(allBooks!=null)
		{
		for (Books books:allBooks) 
		{
				if(books.getBOOKAUTHOR().equalsIgnoreCase(author))
				{
					searchResult.add(books);
				}
		}
		}
		return searchResult;
	}
	@Override
	public List<Books> searchByBookName(String bookname) {
		List<Books> allBooks=entityManager.createQuery("From Books").getResultList();
		List<Books> searchResult = new ArrayList();
		if(allBooks!=null)
		{
		for (Books books:allBooks) 
		{
				if(books.getBOOKNAME().equalsIgnoreCase(bookname))
				{
					searchResult.add(books);
				}
		}
		}
		return searchResult;
	}
	@Override
	public List<Books> searchByBookCategory(String category) {
		List<Books> allBooks=entityManager.createQuery("From Books").getResultList();
		List<Books> searchResult = new ArrayList();
		if(allBooks!=null)
		{
		for (Books books:allBooks) 
		{
			if(books.getBOOKCATEGORY().equalsIgnoreCase(category))
			{
				searchResult.add(books);
			}
		}
		}
		return searchResult;
	}
	@Override
	public Books updateBook(String id, String bookname, String author,
			String publisher, String categoty, int quantity) {
		 Books updates =entityManager.find(Books.class, id);
			if(updates!=null)
			{
				updates.setBOOKID(id);
				updates.setBOOKNAME(bookname);
				updates.setBOOKAUTHOR(author);
				updates.setBOOKPUBLISHER(publisher);
				updates.setBOOKCATEGORY(categoty);
				updates.setBOOKQUANTITY(quantity);
				entityManager.merge(updates);
			}
			else
			{
				updates=null;
			}
			
			return updates;
	}
	@Override
	public Books deleteBook(String id) {
		Books delete=entityManager.find(Books.class, id);
		if(delete!=null)
		{
			entityManager.remove(delete);
		}
		else
		{
			delete = null;
		}
		return delete;

	}
}
