package com.ust_global;

import java.util.List;
import java.util.Properties;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

public class TestUserLogin {

	/**
	 * @param args
	 * @throws NamingException 
	 */
	public static void main(String[] args) throws NamingException {
		// TODO Auto-generated method stub
		Properties p=new Properties();
		p.put(Context.PROVIDER_URL, "localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY, "org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES, "org.jboss.naming:org.jnp.interfaces");
		Context ctx= new InitialContext(p);
		UserLoginBeanRemote userremote =(UserLoginBeanRemote)ctx.lookup("UserLoginBean/remote");
		//boolean found = userremote.validateuser("nss@ust","Kabali");
		boolean all = userremote.validateuser("har@ust", "hr");
		if(all==true)
		{
			 
			System.out.println("Valid");
		}
		if(all==false)
		{
			System.out.println("Invalid");
		}
}

}