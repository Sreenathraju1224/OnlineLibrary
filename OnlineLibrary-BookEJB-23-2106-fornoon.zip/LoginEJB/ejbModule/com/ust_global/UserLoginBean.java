package com.ust_global;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.jboss.security.auth.spi.Users;

/**
 * Session Bean implementation class UserLoginBean
 */
@Stateless
public class UserLoginBean implements UserLoginBeanRemote {

    /**
     * Default constructor. 
     */
	@PersistenceContext(name="UserLoginUnit")
	EntityManager entityManager;
    public UserLoginBean() {
        // TODO Auto-generated constructor stub
    }

	@Override
	public boolean validateuser(String Loginid, String Userpass) {
		UserLogin s=null;
		boolean found =false;
		System.out.println("1 "+Loginid+" and  "+Userpass);
		List<UserLogin>  user =entityManager.createQuery("From Users").getResultList();
//		 s =  (UserLogin) entityManager.createQuery("From Users").getSingleResult();//find(UserLogin.class, userid);
		entityManager.flush();
		if (user!=null)
		{
			for (UserLogin users:user) 
			{
				if(users.getLOGINID().equals(Loginid) && users.getUSERPASS().equals(Userpass))
				{
					found = true;
				}
				else
				{
					found=false;
				}
					
			}
		}
		
		else
		{
		s=null;   
		System.out.println("2 going to return "+found);
		found = false;
		}
		
		//System.out.println("3 "+s.getUsername()+"..."+s.getUserPassword());
		return found;
		
	}

	@Override
	public void addUser(UserLogin s) {
		entityManager.persist(s);
		
	}

}
