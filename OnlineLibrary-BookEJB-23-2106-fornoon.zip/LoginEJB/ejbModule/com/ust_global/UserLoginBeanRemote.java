package com.ust_global;
import javax.ejb.Remote;

@Remote
public interface UserLoginBeanRemote {
	public boolean validateuser(String Loginid,String Userpass);
	public void addUser(UserLogin  s);
	
}
