package com.ust_global;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
@Entity(name ="Users")
public class UserLogin implements Serializable  {
	int 	USERID;
	String  LOGINID;
	String  USERPASS;
	String USERNAME;
	String  USERADDRESS;
	public String getUSERNAME() {
		return USERNAME;
	}
	public void setUSERNAME(String uSERNAME) {
		USERNAME = uSERNAME;
	}
	public String getUSERADDRESS() {
		return USERADDRESS;
	}
	public void setUSERADDRESS(String uSERADDRESS) {
		USERADDRESS = uSERADDRESS;
	}
	@Id
  	@Column(name="USERID")
	public int getUSERID() {
		return USERID;
	}
	public void setUSERID(int uSERID) {
		USERID = uSERID;
	}
	public String getLOGINID() {
		return LOGINID;
	}
	public void setLOGINID(String lOGINID) {
		LOGINID = lOGINID;
	}
	public String getUSERPASS() {
		return USERPASS;
	}
	public void setUSERPASS(String uSERPASS) {
		USERPASS = uSERPASS;
	}
	public UserLogin()
	{
		
	}
	  
}
