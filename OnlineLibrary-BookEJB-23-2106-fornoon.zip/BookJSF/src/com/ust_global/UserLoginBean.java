package com.ust_global;

import java.util.Properties;

import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.http.HttpSession;

public class UserLoginBean {
	int 	uid;
	String  loginid;
	String   userpass;
	String useraddress;
	String uername;
	String msg;
	public String getUseraddress() {
		return useraddress;
	}
	public void setUseraddress(String useraddress) {
		this.useraddress = useraddress;
	}
	public String getUername() {
		return uername;
	}
	public void setUername(String uername) {
		this.uername = uername;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	public int getUid() {
		return uid;
	}
	public void setUid(int uid) {
		this.uid = uid;
	}
	public String getLoginid() {
		return loginid;
	}
	public void setLoginid(String loginid) {
		this.loginid = loginid;
	}
	public String getUserpass() {
		return userpass;
	}
	public void setUserpass(String userpass) {
		this.userpass = userpass;
	}
	public String userLogin() throws NamingException
	{
		Properties p=new Properties();
		p.put(Context.PROVIDER_URL, "localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY, "org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES, "org.jboss.naming:org.jnp.interfaces");
		Context ctx= new InitialContext(p);
		UserLoginBeanRemote m =(UserLoginBeanRemote)ctx.lookup("UserLoginBean/remote");
		System.out.println(m);
		if(m.validateuser(this.loginid, this.userpass))
		{
			msg="LoginHome";
			FacesContext f = FacesContext.getCurrentInstance();
			ExternalContext ec =f.getExternalContext();
			HttpSession session=(HttpSession)ec.getSession(false);
			session.setAttribute("loginid",this.loginid);
		}
		else
		{
			msg="LoginFailure";
		}
		System.out.println("Returning msg");
		return msg;
	}
	public String userLogout()
	{

		System.out.println("reaching logout");
		FacesContext f = FacesContext.getCurrentInstance();
		ExternalContext ec =f.getExternalContext();
		HttpSession session=(HttpSession)ec.getSession(false);
		String msg="";
		if(session!=null)
		{
			System.out.println("session is found");
			String x=(String)session.getAttribute("loginid");
			if(x!=null)
			{
				System.out.println("name is found");
				System.out.println("We are sucessfully goint to logout");
				session.removeAttribute("loginid");
				session.invalidate();
				msg="LoginHome1";
			}
		}
		System.out.println("returning "+msg);
		return msg;
	}
	public String userSignin() throws NamingException
	{
		Properties p=new Properties();
		p.put(Context.PROVIDER_URL, "localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY, "org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES, "org.jboss.naming:org.jnp.interfaces");
		Context ctx= new InitialContext(p);
		UserLoginBeanRemote m =(UserLoginBeanRemote)ctx.lookup("UserLoginBean/remote");
		UserLogin ms = new UserLogin();
		ms.setUSERID(uid);
		ms.setUSERNAME(uername);
		ms.setUSERADDRESS(useraddress);
		ms.setLOGINID(loginid);
		ms.setUSERPASS(userpass);
		m.addUser(ms);
		
		{
			msg="LoginHome";
			FacesContext f = FacesContext.getCurrentInstance();
			ExternalContext ec =f.getExternalContext();
			HttpSession session=(HttpSession)ec.getSession(false);
			session.setAttribute("loginid",this.loginid);
			}
			return msg;
		}
	
		
		
		
	}
		
