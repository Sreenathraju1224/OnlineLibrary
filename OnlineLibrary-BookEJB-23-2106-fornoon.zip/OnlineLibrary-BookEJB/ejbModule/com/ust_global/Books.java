package com.ust_global;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
@Entity(name="Books")
public class Books implements Serializable{
	String  BOOKID;
	String 	BOOKNAME;
	String  BOOKAUTHOR;
	String  BOOKPUBLISHER;
	String  BOOKCATEGORY; 
	int  	BOOKQUANTITY;
	public Books()
	{
		
	}
	@Id
	@Column(name="BOOKID")
	public String getBOOKID() {
		return BOOKID;
	}
	public void setBOOKID(String bOOKID) {
		BOOKID = bOOKID;
	}
	public String getBOOKNAME() {
		return BOOKNAME;
	}
	public void setBOOKNAME(String bOOKNAME) {
		BOOKNAME = bOOKNAME;
	}
	public String getBOOKAUTHOR() {
		return BOOKAUTHOR;
	}
	public void setBOOKAUTHOR(String bOOKAUTHOR) {
		BOOKAUTHOR = bOOKAUTHOR;
	}
	public String getBOOKPUBLISHER() {
		return BOOKPUBLISHER;
	}
	public void setBOOKPUBLISHER(String bOOKPUBLISHER) {
		BOOKPUBLISHER = bOOKPUBLISHER;
	}
	public String getBOOKCATEGORY() {
		return BOOKCATEGORY;
	}
	public void setBOOKCATEGORY(String bOOKCATEGORY) {
		BOOKCATEGORY = bOOKCATEGORY;
	}
	public int getBOOKQUANTITY() {
		return BOOKQUANTITY;
	}
	public void setBOOKQUANTITY(int bOOKQUANTITY) {
		BOOKQUANTITY = bOOKQUANTITY;
	}

}
