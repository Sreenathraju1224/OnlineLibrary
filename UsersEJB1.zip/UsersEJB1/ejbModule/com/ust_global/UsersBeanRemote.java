package com.ust_global;
import java.util.List;

import javax.ejb.Remote;

@Remote
public interface UsersBeanRemote {
 public void AddUser(Users u);
 public List<Users> SearchUSerByName(String UserName);
 public List<Users> readAllUsers();
 public Users updateusers(int id, String uname,String uaddress,String logid,String userpass);
 public Users  DeleteUsers(String id);
}
