package com.ust_global;

import java.util.Properties;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import java.sql.*;
import java.sql.Date;
import java.util.*;
public class BookIssueClient {

	/**
	 * @param args
	 * @throws NamingException 
	 */
	public static void main(String[] args) throws NamingException {
		// TODO Auto-generated method stub
		
		
		
		Properties p=new Properties();
		p.put(Context.PROVIDER_URL,"localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY,"org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES,"org.jboss.naming:org.jnp.interfaces");
		Context ctx=new InitialContext(p);
		
		BookIssueBeanRemote bb=(BookIssueBeanRemote) ctx.lookup("BookIssueBean/remote");
		BookIssue b= new BookIssue();
		
		b.setTransId(8);
		b.setUserName("vaisakh");
		b.setBookId("ML06");
		b.setBookName("Test");
		b.setFine(10);
		
		
		java.util.Date utilDate=new java.util.Date(2016,8,21);
		long ms=utilDate.getTime();
		java.sql.Date sqlDate=new Date(ms);
		
		java.util.Date utilDate1=new java.util.Date(2016,8,30);
		long ms2=utilDate1.getTime();
		java.sql.Date sqlDate1=new Date(ms2);
		
		
		
//		java.sql.Date d=new Date(16,10,18);
//		java.sql.Date d1=new Date(16,10,28);
		b.setDateOfIssue(sqlDate);
		b.setDateOfReturn(sqlDate1);
		bb.addData(b);
		System.out.println("Successfully inserted");
		
	}

}
