package com.ust_global;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

@Stateless
public class BookIssueBean implements BookIssueBeanRemote {

	public BookIssueBean()

	{

	}
	
    @PersistenceContext(name = "BookIssueUnit")
	EntityManager entityManager;

	@Override
	public void addData(BookIssue b) {
		entityManager.persist(b);

	}
}
