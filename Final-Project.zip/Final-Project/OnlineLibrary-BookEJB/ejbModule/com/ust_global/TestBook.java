package com.ust_global;

import java.util.List;
import java.util.Properties;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

public class TestBook {

	/**
	 * @param args
	 * @throws NamingException 
	 */
	public static void main(String[] args) throws NamingException {
		Properties p=new Properties();
		p.put(Context.PROVIDER_URL, "localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY, "org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES, "org.jboss.naming:org.jnp.interfaces");
		Context ctx= new InitialContext(p);
		BooksBeanRemote m =(BooksBeanRemote)ctx.lookup("BooksBean/remote");
		Books ms=new Books();
	//	String id1 = "Ml01";
	//	m.deleteBook(id1);
//		String bookname = "Randamuzam";
//		String author = "M T Vasudevan Nair";
//		String publisher ="D C Books";
//		String category = "Fiction";
//		int quantity = 3;
//		ms.setBOOKID(id1);
//		ms.setBOOKNAME(bookname);
//		ms.setBOOKAUTHOR(author);
//		ms.setBOOKPUBLISHER(publisher);
//		ms.setBOOKCATEGORY(category);
//		ms.setBOOKQUANTITY(quantity);
//		m.addBook(ms);
//		
//		String category ="Fiction";
//		List<Books> book=m.searchByBookCategory(category);
//		if(book!=null)
//		{
//			for (int i = 0; i < book.size(); i++) 
//			{
//				System.out.println(book.get(i).getBOOKID()+" "+book.get(i).getBOOKNAME()+" "+book.get(i).getBOOKAUTHOR());
//			}
//		}
//		else
//			System.out.println("result is null");
//	}
//
//}
		List<Books> allbooks = m.readAllBook();
		if(allbooks !=null)
		{
			for (int i = 0; i < allbooks.size(); i++) 
			{
				System.out.println(allbooks.get(i).getBOOKAUTHOR());
			}
		}
		
	}}